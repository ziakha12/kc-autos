@props([
    'submit'
])
<form action="{{ $submit }}" class="form">
    {{ $inputs }}
</form>
`
