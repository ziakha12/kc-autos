<header class="head shadow-sm pb-2">
      <div class="top-bar">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-4 col-md-3">
                    <p class="text-white nav-phone"><span class="px-2"><i class="fa-solid fa-phone"></i></span>SALES -
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['classes' => 'text-decoration-none text-white','href' => 'tel:123-456-689','type' => 'a','value' => '123-456-689']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['classes' => 'text-decoration-none text-white','href' => 'tel:123-456-689','type' => 'a','value' => '123-456-689']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?></p>
                </div>
                <div class="col-8 col-md-9 col-lg-9">
                    <ul class="primary-navs">
                        <li class="nav-item">
                            <?php if (isset($component)) { $__componentOriginal830fdeaeba0d18fab16a3585e06c655b = $component; } ?>
<?php $component = App\View\Components\Topbar\Link::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('topbar.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Topbar\Link::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'nav-link active','title' => 'About Us','href' => ''.e(route('about-us')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b)): ?>
<?php $component = $__componentOriginal830fdeaeba0d18fab16a3585e06c655b; ?>
<?php unset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b); ?>
<?php endif; ?>
                        </li>
                        <li class="nav-item px-3">
                            <?php if (isset($component)) { $__componentOriginal830fdeaeba0d18fab16a3585e06c655b = $component; } ?>
<?php $component = App\View\Components\Topbar\Link::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('topbar.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Topbar\Link::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'nav-link active','title' => 'Knowledge Bank','href' => '#']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b)): ?>
<?php $component = $__componentOriginal830fdeaeba0d18fab16a3585e06c655b; ?>
<?php unset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b); ?>
<?php endif; ?>
                        </li>
                        <li class="nav-item px-3">
                            <?php if (isset($component)) { $__componentOriginal830fdeaeba0d18fab16a3585e06c655b = $component; } ?>
<?php $component = App\View\Components\Topbar\Link::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('topbar.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Topbar\Link::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'nav-link active','title' => 'Blog','href' => '#']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b)): ?>
<?php $component = $__componentOriginal830fdeaeba0d18fab16a3585e06c655b; ?>
<?php unset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b); ?>
<?php endif; ?>
                        </li>
                        <li class="nav-item px-3">
                            <?php if (isset($component)) { $__componentOriginal830fdeaeba0d18fab16a3585e06c655b = $component; } ?>
<?php $component = App\View\Components\Topbar\Link::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('topbar.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Topbar\Link::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'nav-link active','title' => 'Reviews','href' => '#']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b)): ?>
<?php $component = $__componentOriginal830fdeaeba0d18fab16a3585e06c655b; ?>
<?php unset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b); ?>
<?php endif; ?>
                        </li>
                        <li class="nav-item px-3">
                            <?php if (isset($component)) { $__componentOriginal830fdeaeba0d18fab16a3585e06c655b = $component; } ?>
<?php $component = App\View\Components\Topbar\Link::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('topbar.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Topbar\Link::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'nav-button nav-link text-white px-5','title' => 'Contact','href' => ''.e(route('contact-us')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b)): ?>
<?php $component = $__componentOriginal830fdeaeba0d18fab16a3585e06c655b; ?>
<?php unset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b); ?>
<?php endif; ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
      <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="lower-head d-flex justify-content-between mt-4 align-items-center   ">
                    <div class="logo">
                        <a class="navbar-brand" href="#">
                            <img src="<?php echo e(asset('/assets/images/logo.png')); ?>" alt="kc" >
                          </a>
                    </div>
                    <div class="nav-buttons d-flex ">
                        
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['type' => 'a','id' => '','href' => ''.e(route('signup')).'','classes' => 'signup-btn text-decoration-none mx-1','value' => 'Sign up']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'a','id' => '','href' => ''.e(route('signup')).'','classes' => 'signup-btn text-decoration-none mx-1','value' => 'Sign up']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['type' => 'a','href' => ''.e(route('signin')).'','classes' => 'signin-btn mx-1','value' => 'Sign in']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'a','href' => ''.e(route('signin')).'','classes' => 'signin-btn mx-1','value' => 'Sign in']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>


                    </div>
                </div>
            </div>
        </div>
      </div>
    
</header>
<?php /**PATH C:\xampp\htdocs\kc-autos (2)\resources\views/components/topbar/topbar.blade.php ENDPATH**/ ?>