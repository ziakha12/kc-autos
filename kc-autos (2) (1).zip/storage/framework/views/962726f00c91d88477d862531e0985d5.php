
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'title',
    'description'
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'title',
    'description'
]); ?>
<?php foreach (array_filter(([
    'title',
    'description'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<section class="form-card">
    <div class="container mx-auto">
        <div class="row justify-content-center">
            <div class="col-lg-6 text-center">
                <?php if (isset($component)) { $__componentOriginalb4b6b343860ee628cac14eb64f118e54 = $component; } ?>
<?php $component = App\View\Components\Auth\Form::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Auth\Form::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['submit' => '#','title' => ''.e($title).'','description' => ''.e($description).'']); ?>
                     <?php $__env->slot('inputs', null, []); ?> 
                        <?php echo e($inputs); ?>

                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb4b6b343860ee628cac14eb64f118e54)): ?>
<?php $component = $__componentOriginalb4b6b343860ee628cac14eb64f118e54; ?>
<?php unset($__componentOriginalb4b6b343860ee628cac14eb64f118e54); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php /**PATH C:\xampp\htdocs\kc-autos (2)\resources\views/components/auth/card.blade.php ENDPATH**/ ?>