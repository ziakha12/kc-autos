<script>
    document.title = "About Us| KC Autoconnect";
    document.querySelector('title').innerHTML = document.title;
</script>

<?php $__env->startSection('content'); ?>
    <div class="about-page">
        <section class="banner bg-img">
            <div class="container-fluid">
                <div class="row justify-content-center text-center">
                    <div class="col-md-12">
                        <div>
                            <h1 class="text-lg mb-3">About us</h1>
                            <div class="border-bottom-cs all-center m-auto"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="about-us-sec pb-70">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-sm-12">
                        <img src="<?php echo e(asset('/assets/images/about-us-sec-img.png')); ?>" class="img-fluid" alt="kc">
                    </div>
                    <div class="col-lg-6 col-sm-12">
                    <h4 class="text-md">About Us</h4>
                        <p class="primary-para">
                            Dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum
                            sociis natoque penatibus et magnis Dolor sit amet lacus accumsan et viverra justo commodo. Proin
                            sodales pulvinar tempor. Cum sociis natoque penatibus et magnis Dolor sit amet lacus accumsan et
                            viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis
                            Dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum
                            sociis natoque penatibus et magnis Dolor sit amet lacus accumsan et viverra justo commodo. Proin
                            sodales pulvinar tempor. Cum sociis natoque penatibus et magnis
                        </p>
                        <ul class="d-flex gap-5  ps-0">
                            <li class="primary-para list-unstyled">45 Crescent Road Pinetree Avenue <br>
                            P.O. Box 3242</li>
                                <li class="primary-para text-black list-unstyled">Customer Centre: <br> <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['classes' => 'primary-para text-decoration-none tel-text-md','type' => 'a','href' => 'tel:+614 7343 3254','value' => '+614 7343 3254']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['classes' => 'primary-para text-decoration-none tel-text-md','type' => 'a','href' => 'tel:+614 7343 3254','value' => '+614 7343 3254']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kc-autos (2) (1)\resources\views/screens/user/about.blade.php ENDPATH**/ ?>