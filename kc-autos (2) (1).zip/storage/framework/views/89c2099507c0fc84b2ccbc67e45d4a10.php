<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'classes' => $classes ?? '' ,
    'value',
    'id' => $id ?? '' ,
    'type' => 'button',
    'href'=> $href ?? '',
    'databstarget' => $databstarget ?? '',
    'databstoggle' => $databstoggle ?? '',

]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'classes' => $classes ?? '' ,
    'value',
    'id' => $id ?? '' ,
    'type' => 'button',
    'href'=> $href ?? '',
    'databstarget' => $databstarget ?? '',
    'databstoggle' => $databstoggle ?? '',

]); ?>
<?php foreach (array_filter(([
    'classes' => $classes ?? '' ,
    'value',
    'id' => $id ?? '' ,
    'type' => 'button',
    'href'=> $href ?? '',
    'databstarget' => $databstarget ?? '',
    'databstoggle' => $databstoggle ?? '',

]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if($type == "a"): ?>
    <a href="<?php echo e($href); ?>" class="<?php echo e($classes); ?>" ><?php echo e($value); ?></a>
<?php elseif($type == "button"): ?>
    <button  class="<?php echo e($classes); ?>"  data-bs-toggle="<?php echo e($databstoggle); ?>" data-bs-target="<?php echo e($databstarget); ?>"  id='<?php echo e($id); ?>' ><?php echo e($value); ?></button>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\kc-autos\resources\views/components/button.blade.php ENDPATH**/ ?>