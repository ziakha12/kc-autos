<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'id',
    'title',
    'btnTitle'
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'id',
    'title',
    'btnTitle'
]); ?>
<?php foreach (array_filter(([
    'id',
    'title',
    'btnTitle'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
  <!-- Modal -->
  <div class="modal fade" id="<?php echo e($id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <i class="fa-regular fa-circle-check text-secondary "></i>
            <h2 class="text-secondary"> <?php echo e($title); ?></h2>
        </div>
        <div class="modal-footer justify-content-center">
          <button type="button" class="btn btn-secondary modal-button"><?php echo e($btnTitle); ?></button>
        </div>
      </div>
    </div>
  </div>
<?php /**PATH C:\xampp\htdocs\kc-autoconnect-laravel\resources\views/components/modal.blade.php ENDPATH**/ ?>