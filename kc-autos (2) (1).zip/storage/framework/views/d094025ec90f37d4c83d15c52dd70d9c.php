<?php $__env->startSection('content'); ?>
<div class="offer-page">
    <div class="container">
        <div class="row">
                <div class="col-12">
                    <div class="offer-wrapper">
                        <div class="offer-content d-flex justify-content-between align-items-center">
                            <div class="price">
                                <p>Offer ID : <span class="fw-bold"> 00001</span></p>
                                <h4>550$</h4>
                            </div>
                            <div class="price-btn">
                                <button class="">Accept</button>
                            </div>
                        </div>
                        <div class="offer-date">
                            <p>Date: 12/12/2000</p>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="offer-wrapper">
                        <div class="offer-content d-flex justify-content-between align-items-center">
                            <div class="price">
                                <p>Offer ID : <span class="fw-bold"> 00001</span></p>
                                <h4>550$</h4>
                            </div>
                            <div class="price-btn">
                                <button class="">Accept</button>
                            </div>
                        </div>
                        <div class="offer-date">
                            <p>Date: 12/12/2000</p>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="offer-wrapper">
                        <div class="offer-content d-flex justify-content-between align-items-center">
                            <div class="price">
                                <p>Offer ID : <span class="fw-bold"> 00001</span></p>
                                <h4>550$</h4>
                            </div>
                            <div class="price-btn">
                                <button class="">Accept</button>
                            </div>
                        </div>
                        <div class="offer-date">
                            <p>Date: 12/12/2000</p>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="offer-wrapper">
                        <div class="offer-content d-flex justify-content-between align-items-center">
                            <div class="price">
                                <p>Offer ID : <span class="fw-bold"> 00001</span></p>
                                <h4>550$</h4>
                            </div>
                            <div class="price-btn">
                                <button class="">Accept</button>
                            </div>
                        </div>
                        <div class="offer-date">
                            <p>Date: 12/12/2000</p>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="offer-wrapper">
                        <div class="offer-content d-flex justify-content-between align-items-center">
                            <div class="price">
                                <p>Offer ID : <span class="fw-bold"> 00001</span></p>
                                <h4>550$</h4>
                            </div>
                            <div class="price-btn">
                                <button class="">Accept</button>
                            </div>
                        </div>
                        <div class="offer-date">
                            <p>Date: 12/12/2000</p>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="offer-wrapper">
                        <div class="offer-content d-flex justify-content-between align-items-center">
                            <div class="price">
                                <p>Offer ID : <span class="fw-bold"> 00001</span></p>
                                <h4>550$</h4>
                            </div>
                            <div class="price-btn">
                                <button class="">Accept</button>
                            </div>
                        </div>
                        <div class="offer-date">
                            <p>Date: 12/12/2000</p>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="offer-wrapper">
                        <div class="offer-content d-flex justify-content-between align-items-center">
                            <div class="price">
                                <p>Offer ID : <span class="fw-bold"> 00001</span></p>
                                <h4>550$</h4>
                            </div>
                            <div class="price-btn">
                                <button class="">Accept</button>
                            </div>
                        </div>
                        <div class="offer-date">
                            <p>Date: 12/12/2000</p>
                        </div>
                    </div>
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kc-autoconnect-laravel-2\resources\views/screens/user/offer.blade.php ENDPATH**/ ?>