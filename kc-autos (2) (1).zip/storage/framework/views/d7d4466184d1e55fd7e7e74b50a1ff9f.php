<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'name',
    'type' => 'text',
    'placeholder' => null,
    'required' => false,
    'label' => $label ?? null,
    // 'textarea' => $textarea ?? null,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'name',
    'type' => 'text',
    'placeholder' => null,
    'required' => false,
    'label' => $label ?? null,
    // 'textarea' => $textarea ?? null,
]); ?>
<?php foreach (array_filter(([
    'name',
    'type' => 'text',
    'placeholder' => null,
    'required' => false,
    'label' => $label ?? null,
    // 'textarea' => $textarea ?? null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if($label != null): ?>
<label for="<?php echo e($label); ?>" class="label-feld"><?php echo e(ucwords(str_replace('_', ' ', $label))); ?></label>
<?php endif; ?>

<input type="<?php echo e($type); ?>" id="<?php echo e($label); ?>"  placeholder="<?php echo e($placeholder ?: ucwords(str_replace('_', ' ', $name))); ?>" class="form-control form-input" <?php echo e($required ? 'required' : ''); ?>>
<?php /**PATH C:\xampp\htdocs\kc-autoconnect-laravel-2\resources\views/components/input.blade.php ENDPATH**/ ?>