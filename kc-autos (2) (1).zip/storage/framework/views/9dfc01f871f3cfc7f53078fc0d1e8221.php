
<ul class="dropdown-menu ">
    <div class="notification-body">
        <div class="notification-header">
            <p>Notifications</p>
        </div>
        <div class="notification-content">
                <div class="content-head d-flex justify-content-between">
                    <div class="unread">
                        <p>Unread</p>
                    </div>
                    <div class="mark-read  rounded-2">
                       <button>mark as read</button>
                    </div>
              </div>
              <div class="notify-main">
                <div class="first d-flex">
                    <div class="dot">
                        .
                    </div>
                    <div class="image pl-2">
                         <img src="<?php echo e(asset('/assets/images/Avatar.png')); ?>" alt="kc">
                    </div>
                    <div class="notify-title">
                        <p class="px-2">Stewie Griffin invited you to Resources_ Product_Growth_Org Design.paper</p>
                        <div class="notify-file d-flex px-2">
                            <img src="<?php echo e(asset('/assets/images/dropbox.png')); ?>" alt="kc" >
                            <p class="pl-2">Resources_ Product_Growth_Org Design....</p>
                        </div>
                        <p class="notify-time text-secondary mt-2">3 months ago</p>
                    </div>
                </div>
              </div>
              <h3 class="px-3">Recent</h3>
              <div class="notify-main">
                <div class="first d-flex">
                    <div class="image pl-2">
                        <img src="<?php echo e(asset('/assets/images/Avatar -2.png')); ?>" alt="kc" >
                    </div>
                    <div class="notify-title">
                        <p class="px-2">Meg Griffin invited you to edit the folder  Logo graphics</p>
                        <div class="notify-file d-flex px-2">
                            <img src="<?php echo e(asset('/assets/images/file-2.png')); ?>" alt="kc" >
                            <p class="pl-2">Files</p>
                        </div>
                        <p class="notify-time text-secondary mt-2">july 1,2023</p>
                    </div>
                </div>
            </div>

        </div>
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['href' => ''.e(route('notification-view')).'','type' => 'a','classes' => 'text-secondary notify-link','value' => 'View More']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('notification-view')).'','type' => 'a','classes' => 'text-secondary notify-link','value' => 'View More']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>
  </ul>
<?php /**PATH C:\xampp\htdocs\kc-autos (2) (1)\resources\views/components/user/notification.blade.php ENDPATH**/ ?>