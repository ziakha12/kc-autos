<header class="head shadow-sm pb-2">
    <nav class="navbar navbar-expand-lg">
        <div class="container">
          <p class="text-white nav-phone"><span class="px-2"><i class="fa-solid fa-phone"></i></span>Sales - 123-456-689</p>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <?php if (isset($component)) { $__componentOriginal830fdeaeba0d18fab16a3585e06c655b = $component; } ?>
<?php $component = App\View\Components\Topbar\Link::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('topbar.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Topbar\Link::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'nav-link active','title' => 'About Us','href' => '#']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b)): ?>
<?php $component = $__componentOriginal830fdeaeba0d18fab16a3585e06c655b; ?>
<?php unset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b); ?>
<?php endif; ?>
              </li>
              <li class="nav-item px-3">
                <?php if (isset($component)) { $__componentOriginal830fdeaeba0d18fab16a3585e06c655b = $component; } ?>
<?php $component = App\View\Components\Topbar\Link::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('topbar.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Topbar\Link::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'nav-link active','title' => 'Knowledge Bank','href' => '#']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b)): ?>
<?php $component = $__componentOriginal830fdeaeba0d18fab16a3585e06c655b; ?>
<?php unset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b); ?>
<?php endif; ?>
              </li>
              <li class="nav-item px-3">
                <?php if (isset($component)) { $__componentOriginal830fdeaeba0d18fab16a3585e06c655b = $component; } ?>
<?php $component = App\View\Components\Topbar\Link::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('topbar.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Topbar\Link::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'nav-link active','title' => 'Blog','href' => '#']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b)): ?>
<?php $component = $__componentOriginal830fdeaeba0d18fab16a3585e06c655b; ?>
<?php unset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b); ?>
<?php endif; ?>
              </li>
              <li class="nav-item px-3">
                <?php if (isset($component)) { $__componentOriginal830fdeaeba0d18fab16a3585e06c655b = $component; } ?>
<?php $component = App\View\Components\Topbar\Link::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('topbar.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Topbar\Link::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'nav-link active','title' => 'Reviews','href' => '#']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b)): ?>
<?php $component = $__componentOriginal830fdeaeba0d18fab16a3585e06c655b; ?>
<?php unset($__componentOriginal830fdeaeba0d18fab16a3585e06c655b); ?>
<?php endif; ?>
              </li>
              <li class="nav-item px-3">
                <a class="nav-button nav-link text-white px-5" href="">
                    Contact
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="lower-head d-flex justify-content-between mt-4 align-items-center   ">
                    <div class="logo">
                        <a class="navbar-brand" href="#">
                            <img src="<?php echo e(asset('/assets/images/logo.png')); ?>" alt="kc" >
                          </a>
                    </div>
                    <div class="nav-buttons d-flex ">
                        <button href="#" class="signup-btn mx-1"> Sign up</button>
                        <button href="#" class="signin-btn mx-1"> Sign in</button>

                    </div>
                </div>
            </div>
        </div>
      </div>
    
</header>
<?php /**PATH C:\xampp\htdocs\kc-autoconnect-laravel\resources\views/components/topbar/topbar.blade.php ENDPATH**/ ?>